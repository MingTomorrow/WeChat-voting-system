<template>
	<web-view src="http://www.java1234.com/vip.html"></web-view>
</template>

<script>
</script>

<style>
</style>
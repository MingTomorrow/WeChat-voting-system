<template>
	<view class="rank">
		<view class="voteItem" v-for="item in voteItemList">
			<view class="itemName">
				{{item.name}}
			</view>
			<view class="number">
				{{item.number}}票
			</view>
		</view>
	</view>
</template>

<script>
import {getBaseUrl, requestUtil} from "../../util/requestUtil.js"
	export default{
		data(){
			return{
				voteItemList:{}
			}
		},
		onLoad(e) {
			console.log(e.id)
			this.getRankByVoteId(e.id)
		},
		methods:{
			getRankByVoteId:async function(voteId){
				const result=await requestUtil({url:"/voteItem/rank/"+voteId,method:"get"});
				console.log(result)
				this.voteItemList=result.voteItemList
			}
		}
	}
	
</script>

<style lang="scss">
	.rank{
		padding: 15px;	
		background-color: white;
		.voteItem{
			display: flex;
			justify-content: space-between;
			border-radius: 10px;
			background-color: #f4f5f7;
			padding: 15px;
			margin-bottom: 10px;
			.itemName{
				
			}
			.number{
				
			}
		}
	}
</style>
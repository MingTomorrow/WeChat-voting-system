<template>
	<view class="detail">
		<view class="header">
			<view>
				<text class="option">[选项]</text>&nbsp;&nbsp;<text class="itemName">{{voteItemName}}</text>&nbsp;&nbsp;
			</view>
			<view>
				<text class="total">[共{{voteDetailList.length}}票]</text>
			</view>
		</view>
		<view class="list">
			<block v-for="(value,index) in voteDetailList" :key="index">
				<view class="item">
					<view class="people">
						<view class="user_image">
							<image :src="this.baseUrl+'/image/userAvatar/'+value.wxUserInfo.avatarUrl" ></image>
						</view>
						<view class="user_name_wrap">
							<text class="nick_name">{{value.wxUserInfo.nickName}}</text>
							<text class="vote_date">投票时间：{{value.voteDate}}</text>
						</view>
					</view>
				</view>
			</block>
		</view>
	</view>
</template>

<script>
	import {getBaseUrl, requestUtil} from "../../util/requestUtil.js"
	
	export default{
		
		data(){
			return{
				voteDetailList:[],
				voteItemName:'',
				baseUrl:''
			}
		},
		onLoad(e) {
			console.log(e.voteId);
			console.log(e.voteItemId);
			console.log(e.voteItemName);
			this.voteItemName=e.voteItemName
			this.getVoteDetailInfo(e.voteId,e.voteItemId);
			this.baseUrl=getBaseUrl();
		},
		methods:{
			getVoteDetailInfo:async function(voteId,voteItemId){
				const result=await requestUtil({url:"/voteDetail/"+voteId+"/"+voteItemId,method:"get"});
				console.log(result)
				this.voteDetailList=result.voteDetailList;
			}
		}
		
	}
	
</script>

<style lang="scss">
	
	.detail{
		.header{
			padding-left: 20px;
			padding-top: 20px;
			padding-bottom: 20px;
			padding-right: 20px;
			display: flex;
			justify-content: space-between;
			.option{
				color: green;
			}
			.total{
				color: green;
				font-size: 13px;
			}
		}
		.list{
			.item{
				background-color: white;
				margin-bottom: 5px;
				padding: 10px;
				.people{
					display: flex;
					flex-direction: row;
					.user_image{
						width: 100rpx;
						height: 100rpx;
						text-align: center;
						padding: 0rpx;
						margin: 0rpx;
						image{
							border-radius: 50%;
							width: 90rpx;
							height: 90rpx;
						}
					}
					.user_name_wrap{
						display: flex;
						flex-direction: column;
						padding-left: 10px;
						.nick_name{
							
						}
						.vote_date{
							padding-top: 10rpx;
							font-size: 25rpx;
						}
						
					}
				}
			}
		}
	}
	
</style>
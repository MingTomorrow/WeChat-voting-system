<template>
	<view>客服页面</view>
	<view>锋哥微信：java9266 备用 java8822</view>
	<view>官网: www.java1234.vip</view>
</template>

<script>
</script>

<style>
</style>
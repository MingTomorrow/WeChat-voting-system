package com.java1234.service.impl;

import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.java1234.entity.VoteDetail;
import com.java1234.mapper.VoteDetailMapper;
import com.java1234.service.IVoteDetailService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

/**
 * 投票详情Service实现类
 * @author java1234_小锋 （公众号：java1234）
 * @site www.java1234.vip
 * @company 南通小锋网络科技有限公司
 */
@Service("voteDetailService")
public class IVoteDetailServiceImpl extends ServiceImpl<VoteDetailMapper, VoteDetail> implements IVoteDetailService {

    @Autowired
    private VoteDetailMapper voteDetailMapper;
}

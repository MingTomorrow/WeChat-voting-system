package com.java1234.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.java1234.entity.VoteItem;

/**
 * 投票选项Service接口
 */
public interface IVoteItemService extends IService<VoteItem> {
}

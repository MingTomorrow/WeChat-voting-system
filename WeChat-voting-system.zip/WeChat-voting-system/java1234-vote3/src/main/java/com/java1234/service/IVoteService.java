package com.java1234.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.java1234.entity.Vote;

/**
 * 投票Service接口
 */
public interface IVoteService extends IService<Vote> {
}

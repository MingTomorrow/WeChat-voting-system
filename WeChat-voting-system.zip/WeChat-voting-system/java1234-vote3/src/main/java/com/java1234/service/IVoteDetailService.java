package com.java1234.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.java1234.entity.VoteDetail;

/**
 * 投票详情Service接口
 */
public interface IVoteDetailService extends IService<VoteDetail> {
}

/*
SQLyog Ultimate v11.33 (64 bit)
MySQL - 5.7.18-log : Database - db_vote3
*********************************************************************
*/

/*!40101 SET NAMES utf8 */;

/*!40101 SET SQL_MODE=''*/;

/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
CREATE DATABASE /*!32312 IF NOT EXISTS*/`db_vote3` /*!40100 DEFAULT CHARACTER SET utf8 */;

USE `db_vote3`;

/*Table structure for table `t_vote` */

DROP TABLE IF EXISTS `t_vote`;

CREATE TABLE `t_vote` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(600) DEFAULT NULL,
  `explanation` varchar(3000) DEFAULT NULL,
  `cover_image` varchar(600) DEFAULT NULL,
  `vote_end_time` datetime DEFAULT NULL,
  `openid` varchar(600) DEFAULT NULL,
  `type` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8;

/*Data for the table `t_vote` */

insert  into `t_vote`(`id`,`title`,`explanation`,`cover_image`,`vote_end_time`,`openid`,`type`) values (2,'1','2','20230517045026000000236.jpg','2023-05-20 16:50:22','o30ur5JpAsAUyGBkR0uW4IxvahR8',2),(4,'1','2','20230521102103000000159.jpg','2023-05-22 10:20:32','o30ur5JpAsAUyGBkR0uW4IxvahR8',1),(5,'www','1','20230521123953000000327.jpg','2023-05-22 12:39:50','o30ur5JpAsAUyGBkR0uW4IxvahR8',1),(6,'1','2','20230522085421000000169.jpg','2023-05-23 20:54:17','o30ur5JpAsAUyGBkR0uW4IxvahR8',1);

/*Table structure for table `t_vote_detail` */

DROP TABLE IF EXISTS `t_vote_detail`;

CREATE TABLE `t_vote_detail` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `vote_id` int(11) DEFAULT NULL,
  `vote_item_id` int(11) DEFAULT NULL,
  `vote_date` datetime DEFAULT NULL,
  `openid` varchar(600) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8;

/*Data for the table `t_vote_detail` */

insert  into `t_vote_detail`(`id`,`vote_id`,`vote_item_id`,`vote_date`,`openid`) values (2,2,3,'2023-05-20 12:09:39','o30ur5JpAsAUyGBkR0uW4IxvahR8'),(3,4,9,'2023-05-21 10:21:27','o30ur5JpAsAUyGBkR0uW4IxvahR8'),(5,4,9,'2023-05-21 10:49:14','o30ur5PiPOr52bBsetXcIV93NL-U'),(6,5,10,'2023-05-21 12:40:14','o30ur5JpAsAUyGBkR0uW4IxvahR8');

/*Table structure for table `t_vote_item` */

DROP TABLE IF EXISTS `t_vote_item`;

CREATE TABLE `t_vote_item` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `vote_id` int(11) DEFAULT NULL,
  `name` varchar(600) DEFAULT NULL,
  `image` varchar(600) DEFAULT NULL,
  `number` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8;

/*Data for the table `t_vote_item` */

insert  into `t_vote_item`(`id`,`vote_id`,`name`,`image`,`number`) values (3,2,'1','20230517045034000000735.jpg',1),(4,2,'2','20230517045037000000283.jpg',0),(5,2,'长城','20230517045042000000183.jpg',0),(8,4,'1',NULL,1),(9,4,'2',NULL,2),(10,5,'1',NULL,1),(11,5,'2',NULL,0),(12,6,'1',NULL,0),(13,6,'2',NULL,0);

/*Table structure for table `t_wxuserinfo` */

DROP TABLE IF EXISTS `t_wxuserinfo`;

CREATE TABLE `t_wxuserinfo` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `openid` varchar(90) DEFAULT NULL,
  `nick_name` varchar(150) DEFAULT NULL,
  `avatar_url` varchar(600) DEFAULT NULL,
  `register_date` datetime DEFAULT NULL,
  `last_login_date` datetime DEFAULT NULL,
  `status` char(3) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=20 DEFAULT CHARSET=utf8;

/*Data for the table `t_wxuserinfo` */

insert  into `t_wxuserinfo`(`id`,`openid`,`nick_name`,`avatar_url`,`register_date`,`last_login_date`,`status`) values (7,'o30ur5PiPOr52bBsetXcIV93NL-U','小锋四号@java1234','20230410102248000000487.jpg','2023-04-10 10:21:30','2023-05-21 10:23:32','0'),(9,'o30ur5JpAsAUyGBkR0uW4IxvahR0','微信用户','default.png','2023-04-30 07:42:19','2023-04-30 07:42:19','1'),(10,'1',NULL,NULL,NULL,NULL,'1'),(11,'2',NULL,NULL,NULL,NULL,'1'),(12,'3',NULL,NULL,NULL,NULL,'1'),(13,'4',NULL,NULL,NULL,NULL,'1'),(14,'5',NULL,NULL,NULL,NULL,'1'),(15,'6',NULL,NULL,NULL,NULL,'1'),(16,'7',NULL,NULL,NULL,NULL,'1'),(17,'8',NULL,NULL,NULL,NULL,'1'),(19,'o30ur5JpAsAUyGBkR0uW4IxvahR8','小锋111@java1234','20230514112056000000757.jpeg','2023-05-11 08:44:11','2023-05-22 20:56:48','0');

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;
